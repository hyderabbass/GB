#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'Mian Saleem', 'Tecdiary IT Solutions', 'No. 1, Street 1, Black A, My Condo ', 'Kuala Lumpur', 'WP', '58100', 'Malaysia', '0123456789', 'saleem@tecdiary.com', 'logo.png', 'Thank you for your business!', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (1, 'C1', 'Category 1');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;h3&gt;Thank you for Purchasing Stock Manager Advance 2 with POS Module &lt;/h3&gt;\r\n&lt;p&gt;\r\n This is latest the latest release of Stock Manager Advance.\r\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `region` varchar(55) NOT NULL,
  `alternative_address` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `home_number` varchar(20) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `emergency_number` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `id_number` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `coordinator_name` varchar(55) NOT NULL,
  `credit_allowance` varchar(100) DEFAULT NULL,
  `place_of_work` varchar(55) NOT NULL,
  `no_of_work` varchar(55) NOT NULL,
  `proof_of_address` varchar(55) NOT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (2, 'yogesh', 'storm-edge', '23,bertaud avenue', 'Q.bornes', 'plain wilhems', 'dfdf', 'mauritius', '34344343434', '', '', '0000-00-00', 'yo@gmail.com', 'f233233323256H', '', '', '', '', '', '0', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (3, 'John Doe', 'freelance ltd', 'Rue Mamode', 'P.Louis', 'Moka', '56778990', 'Mauritius', '23059203344', '', '', '1989-11-06', 'john_doe@live.mu', 'J06118923456D', '', '', '', '', '', '0', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (8, 'Bernard', 'bernard ltd', 'campus road', 'Rose-hill', '15, caro laliange ave, phoenix', '3253', 'Mauritius', '23057994555', '23057889900', '23059995555', '1985-08-21', 'bernar@intnet.mu', 'B210885446734F', 'Cristian', 'Roberto', '2332344556', '', '', '0', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (9, 'test', 'test ltd', '24, test ave', 'test', '24, test ave', '3253', 'test', '545545455454', '23057889900', '23059995555', '1985-08-21', 'test@hotmail.com', 'B210885446734F', 'test', 'test', '2332344556', 'test', 'four', '0', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (10, 'test', 'test ltd', '24, test ave', 'test', 'trrt', '3253', 'test', '23057994555', '23057889900', '23059995555', '1990-09-09', 'test@hotmail.com', 'B210885446734F', 'test', 'test', '3555454554', 'test', 'test', '0', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `region`, `alternative_address`, `postal_code`, `country`, `home_number`, `mobile_number`, `emergency_number`, `dob`, `email`, `id_number`, `religion`, `coordinator_name`, `credit_allowance`, `place_of_work`, `no_of_work`, `proof_of_address`, `cf4`, `cf5`, `cf6`) VALUES (11, 'test', 'test ltd', 'ttttttttt', 'ttttttt', 'ttttt44', 'test', 'ttttttt', '2222222222222', '2222222222222', '2222222222222', '1985-08-21', 'test@hotmail.com', 'B210885446734Fbb', 'test', 'rrrr', 'ccccc', 'pppppp', 'nnnnn', 'yes', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(4,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (1, '\0\0', 'sales@tecdiary.com', 1383739955);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (2, '\0\0', 'sale@tecdiary.com', 1383739965);


#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 1, 1, 1, 'yes', NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `size` varchar(55) NOT NULL,
  `um` varchar(55) DEFAULT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `size`, `um`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, '122233333', 'mobile', '50', '', NULL, '3000.00', '4000.00', 40, '1.jpg', 1, 0, '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `batch_number` varchar(55) NOT NULL,
  `expiry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `batch_number`, `expiry_date`) VALUES (1, 1, 1, '122233333', 'mobile', 1, '3000.00', NULL, '3000.00', '', '0000-00-00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `batch_number`, `expiry_date`) VALUES (2, 2, 1, '122233333', 'mobile', 55, '3000.00', NULL, '165000.00', '', '0000-00-00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `batch_number`, `expiry_date`) VALUES (3, 3, 1, '122233333', 'mobile', 2, '3000.00', NULL, '6000.00', '', '0000-00-00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `product_code`, `product_name`, `quantity`, `unit_price`, `tax_amount`, `gross_total`, `batch_number`, `expiry_date`) VALUES (4, 4, 1, '122233333', 'mobile', 7, '3000.00', NULL, '21000.00', '', '0000-00-00');


#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`) VALUES (1, 'PO-0001', 1, 1, 'Test Supplier', '2013-11-05', '', '3000.00', 'Owner Owner', NULL);
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`) VALUES (2, 'PO-0002', 1, 1, 'Test Supplier', '2013-11-06', '', '165000.00', 'Owner Owner', NULL);
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`) VALUES (3, 'PO-0003', 2, 1, 'Test Supplier', '2013-11-06', '&lt;p &gt;\r\n try it!!!\r\n&lt;/p&gt;', '6000.00', 'Owner Owner', NULL);
INSERT INTO purchases (`id`, `reference_no`, `warehouse_id`, `supplier_id`, `supplier_name`, `date`, `note`, `total`, `user`, `updated_by`) VALUES (4, 'PO-0004', 1, 1, 'Test Supplier', '2013-11-06', '', '21000.00', 'Owner Owner', NULL);


#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (1, 1, 1, '122233333', 'mobile', '50', 2, '24.00%', 23, '4000.00', '92000.00', '22080.00', '', '2852.00', '2.50%', 2);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`) VALUES (1, 'SL-0001', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2013-11-06', NULL, NULL, '92000.00', '22080.00', '116748.00', NULL, NULL, '5520.00', 3, '2852.00', 0, 'Owner Owner', NULL, 'CC', 23, '0.00');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '1.2',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`) VALUES (1, 'header_logo.png', 'login_logo.png', 'Stock Manager Advance', 'english', 1, 'USD', 2, 2, 10, 9, 30, '2.0', 3, 3, 'SL', 'QU', 'PO', 'TR', 'code128', 'blue', 1, 2, 2, 2, 1, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'Test Supplier', 'Supplier Company Name', 'Supplier Address', 'Petaling Jaya', 'Selangor', '46050', 'Malaysia', '0123456789', 'supplier@tecdiary.com', '-', '-', '-', '-', '-', '-');


#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(4,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, 'GST', '6.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (4, 'PVM', '21.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'owner', '54af4ba64ec0a86f4f3e1e45159df08902ab8f40', NULL, 'owner@tecdiary.com', NULL, NULL, NULL, '6d51ca3212f297271477fb4f3ec312d68dfd1702', 1351661704, 1383798156, 1, 'Owner', 'Owner', 'Stock Manager', '0105292122');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (1, 'WHI', 'Warehouse 1', 'Address', 'City');
INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (2, 'WHII', 'Warehouse 2', 'Address', 'City');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (1, 1, 1, 40);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (2, 1, 2, 2);


